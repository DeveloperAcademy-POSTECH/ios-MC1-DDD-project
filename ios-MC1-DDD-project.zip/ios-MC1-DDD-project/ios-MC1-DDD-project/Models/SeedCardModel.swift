//
//  SeedCardModel.swift
//  ios-MC1-DDD-project
//
//  Created by Park Sungmin on 2022/04/12.
//


//
import Foundation

struct SeedCard {
    var seedFaceIndex: Int
    var seedShapeIndex: Int
    var seedColorIndex: Int
    
    var seedFace: String {
        get {
            return "ImojiPNG\(seedFaceIndex)"
        }
    }
    
    var seedShape: String {
        get {
            return "ShapePNG\(seedShapeIndex)"
        }
    }
    
    var seedColor: String {
        get {
            return "Color\(seedColorIndex)"
        }
    }
    
    private var seedNameOrigin: String
    var seedName: String {
        get {
            if(seedIsEvolved) {
                return "\(self.seedNameOrigin) 나무"
            }
            else {
                return "\(self.seedNameOrigin) 씨앗"
            }
        }
        
        set(newValue) {
            self.seedNameOrigin = newValue
        }
    }
    
    var seedKeyword: [String]?
    
    var seedCreatedDate: Date
    
    
    var seedQuestionList: [String] = []
    
    var seedDiaryTitle: String = ""
    var seedDiary: String = ""
    
    var seedRetrospectQuestionList: [String] = []
    var seedRetrospectTitle: String = ""
    var seedRetrospect: String = ""
    
    var seedIsEvolved: Bool = false
    
    
    init(seedFaceIndex: Int, seedShapeIndex: Int, seedColorIndex: Int, seedName: String, seedKeyword: [String]?) {
        self.seedFaceIndex = seedFaceIndex
        self.seedShapeIndex = seedShapeIndex
        self.seedColorIndex = seedColorIndex
        
        self.seedNameOrigin = seedName
        self.seedKeyword = seedKeyword
        self.seedCreatedDate = Date()
    }
    
    static let dateFormat: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat  = "YYYY. MM. dd"
        return formatter
     }()

    static let dayDateFormat: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat  = "d"
        return formatter
     }()
    
}

extension SeedCard {
    static var sampleSeedCard: SeedCard =  {
        var sampleSeedCard = SeedCard(seedFaceIndex: 4, seedShapeIndex: 7, seedColorIndex: 4, seedName: "가즈윌", seedKeyword: ["가즈윌", "그녀는", "신인가"])
    
        sampleSeedCard.seedQuestionList = ["어떤 점이 변하면 이 문제가 해결되었다고 할 수 있을까?", "이 문제가 더 심각해진다면, 어떤게 변할까?", "이 문제를 해결하기 위해 어떤 것들을 시도해볼 수 있을까?"]
        sampleSeedCard.seedDiaryTitle = "오늘의 회고"
        sampleSeedCard.seedDiary = "별과 거선의 반짝이는 뛰노는 가지에 끝에 쓸쓸하랴? 붙잡아 능히 넣는 속잎나고, 생생하며, 꽃이 커다란 것이다. 뼈 인간이 곧 심장은 끓는다. 사는가 일월과 우리는 가치를 있는가? 바로 황금시대의 할지니, 맺어, 커다란 얼마나 능히 품에 얼음과 아니다. 살 꽃이 봄바람을 뼈 있음으로써 피다. 있는 고동을 같이, 사막이다. 고동을 평화스러운 있으며, 위하여, 온갖 사라지지 보이는 듣는다. 옷을 곧 영원히 인생에 인간이 아름답고 천고에 풀이 무엇을 때문이다. 아니더면, 위하여 생명을 놀이 희망의 찾아다녀도, 아름다우냐?"
        
        sampleSeedCard.seedRetrospectQuestionList = ["유소년에게서 아니더면, 이성은 속에 피다.", "능히 대한 두기 미묘한 두손을 가지에 인생을 대중을 것이다.", "끝까지 싸인 실현에 방지하는 사막이다."]
        sampleSeedCard.seedRetrospectTitle = "다시보기 회고"
        sampleSeedCard.seedRetrospect = "못할 가치를 행복스럽고 뿐이다. 너의 산야에 바이며, 주며, 모래뿐일 싸인 두손을 어디 것이다. 발휘하기 그들은 천하를 대중을 봄바람이다. 어디 새가 크고 것이다. 속에서 있을 어디 놀이 피부가 따뜻한 그리하였는가? 길을 품었기 싶이 얼마나 붙잡아 스며들어 노래하며 청춘 힘있다. 그들은 따뜻한 열락의 날카로우나 일월과 청춘의 살 놀이 것이다. 위하여서, 이상, 동산에는 아름다우냐? 그들의 이것을 품에 풍부하게 품고 있다."
        
        return sampleSeedCard
    }()
}
