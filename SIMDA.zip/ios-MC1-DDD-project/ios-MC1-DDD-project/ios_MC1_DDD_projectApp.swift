//
//  SwiftUIView.swift
//  ios-MC1-DDD-project
//
//  Created by Park Sungmin on 2022/04/12.
//

import SwiftUI


@main
struct ios_MC1_DDD_projectApp: App {
    var body: some Scene {
        WindowGroup {
            MainPageView()
        }
    }
}
