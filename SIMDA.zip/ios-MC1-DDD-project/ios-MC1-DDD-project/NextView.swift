//
//  NextView.swift
//  ios-MC1-DDD-project
//
//  Created by kimhyeongmin on 2022/04/11.
//

import SwiftUI

struct NextView: View {
    var body: some View {
        Text("ThisIsNextPage")
            .foregroundColor(Color.red)
            }
    }

struct NextView_Previews: PreviewProvider {
    static var previews: some View {
        NextView()
    }
}
